import random
import string
import group_globalVar as globalvar
from _datetime import datetime, timedelta

ackalerts=[]
sharedfolderslist=[]
policyfolderslist=[]

now_datetime = datetime.now()
start_of_day_datetime = now_datetime.replace(hour=00, minute=00, second=00)
end_of_day_datetime = now_datetime.replace(hour=23, minute=59, second=59)
start_timestamp = int(round(start_of_day_datetime.timestamp() * 1000))
end_timestamp = int(round(end_of_day_datetime.timestamp() * 1000))
isostart = datetime.utcfromtimestamp(start_timestamp/1000).strftime('%Y-%m-%dT%H:%M:%S.000Z')
isoend = datetime.utcfromtimestamp(end_timestamp/1000).strftime('%Y-%m-%dT%H:%M:%S.999Z')
# Get today's date
presentday = datetime.today()
# Get Yesterday
yesterday = presentday.replace(hour=23, minute=59, second=59) - timedelta(1)
yesterday_timestamp = int(round(yesterday.timestamp() * 1000))
isoyesterday = datetime.utcfromtimestamp(yesterday_timestamp / 1000).strftime('%Y-%m-%dT%H:%M:%S.000Z')
# Get custom date
custom = presentday.replace(hour=23, minute=59, second=59) - timedelta(2)
custom_timestamp = int(round(custom.timestamp() * 1000))
isocustom = datetime.utcfromtimestamp(custom_timestamp / 1000).strftime('%Y-%m-%dT%H:%M:%S.000Z')
# Get Tomorrow
tomorrow = presentday + timedelta(1)
customnextdate = presentday.replace(hour=23, minute=59, second=59) + timedelta(2)
customnextdate_timestamp = int(round(customnextdate.timestamp() * 1000))
# Get month
month = presentday.replace(hour=23, minute=59, second=59) - timedelta(30)
month_timestamp = int(round(month.timestamp() * 1000))
isomonth = datetime.utcfromtimestamp(month_timestamp / 1000).strftime('%Y-%m-%dT%H:%M:%S.000Z')


C=6
createglobalfolders= {
  "name": ''.join(random.choices(string.ascii_uppercase + string.digits, k=C)),
  "policies": [],
  "shared": True,
  "actCode": "Q6Y5Q"
}

B=6
createpolicyfolders={
  "name": ''.join(random.choices(string.ascii_uppercase + string.digits, k=B)),
  "policies": [
    {
      "policyId": "5f27d3bcfce9664744139ae1",
      "policyName": "Default Android Kiosk",
      "policyType": "ANDROID_KIOSK"
    }
  ],
  "shared": False,
  "actCode": "Q6Y5Q"
}

PolicygroupconfigwithSign = {
  "s3Config": {
    "enabled": True,
    "identityPoolId": "us-west-2:9e8b7389-6218-4d4c-bca4-1768f3791613",
    "region": "us-west-2",
    "bucketName": [
      "laf-dev"
    ]
  },
  "signEnabled": True,
  "uploadSizeLimit": "10000000",
  "type": "Policy",
  "policyId": "5f27d3bcfce9664744139ae1"
}

PolicygroupconfigwithoutSign = {
  "s3Config": {
    "enabled": True,
    "identityPoolId": "us-west-2:9e8b7389-6218-4d4c-bca4-1768f3791613",
    "region": "us-west-2",
    "bucketName": [
      "laf-dev"
    ]
  },
  "signEnabled": False,
  "uploadSizeLimit": "10000000",
  "type": "Policy",
  "policyId": "5f27d3bcfce9664744139ae1"
}

SharedFolderconfigwithSign = {
  "s3Config": {
    "enabled": True,
    "identityPoolId": "us-west-2:9e8b7389-6218-4d4c-bca4-1768f3791613",
    "region": "us-west-2",
    "bucketName": [
      "laf-dev"
    ]
  },
  "signEnabled": True,
  "uploadSizeLimit": "5000000",
  "type": "Shared",
  "activationCode": "Q6Y5Q"
}

SharedFolderconfigwithoutSign = {
  "s3Config": {
    "enabled": True,
    "identityPoolId": "us-west-2:9e8b7389-6218-4d4c-bca4-1768f3791613",
    "region": "us-west-2",
    "bucketName": [
      "laf-dev"
    ]
  },
  "signEnabled": False,
  "uploadSizeLimit": "5000000",
  "type": "Shared",
  "activationCode": globalvar.actcode
}


AddingAmazonS3folder={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 853,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": None,
  "passcodeInterval": "120000",
  "showLinks": True,
  "sdCard": {
    "enabled": True,
    "files": None
  },
  "googleDrive": {
    "enabled": False,
    "files": None
  },
  "dropBox": {
    "enabled": False,
    "files": None
  },
  "s3Config": {
    "enabled": True,
    "identityPoolId": "us-west-2:9e8b7389-6218-4d4c-bca4-1768f3791613",
    "region": "us-west-2",
    "bucketName": [
      "laf-dev"
    ]
  }
}

AddingDropboxfolder={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 853,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": None,
  "passcodeInterval": 120000,
  "showLinks": True,
  "sdCard": {
    "enabled": True,
    "files": None
  },
  "googleDrive": {
    "enabled": True,
    "files": None
  },
  "dropBox": {
    "enabled": True,
    "files": [
      {
        "uniqueID": "1586751147798907997",
        "fName": None,
        "fSize": 0,
        "fPath": "https://www.dropbox.com/sh/9sirqndavlbv4lv/AACz95VSaVso9A_weDup3cwVa?dl=0",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": 9,
        "label": "QA Team"
      },
      {
        "uniqueID": "5014251260363229112",
        "fName": None,
        "fSize": 0,
        "fPath": "https://www.dropbox.com/s/df49s38nvtjmnog/managing_securing_mobile_devices_9781119349846.pdf?dl=0",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": 9,
        "label": "MDM"
      },
      {
        "label": "WeBox",
        "fPath": "https://www.dropbox.com/s/tywjhg1lvluo8vl/WeBox.pdf?dl=0",
        "fileType": 9
      }
    ]
  },
  "s3Config": {
    "enabled": True,
    "identityPoolId": "us-west-2:9e8b7389-6218-4d4c-bca4-1768f3791613",
    "region": "us-west-2",
    "bucketName": [
      "laf-dev"
    ]
  }
}

AddingGoogleDrivefolder={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 853,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": None,
  "passcodeInterval": 120000,
  "showLinks": True,
  "sdCard": {
    "enabled": True,
    "files": None
  },
  "googleDrive": {
    "enabled": True,
    "files": [
      {
        "uniqueID": "6950513484462702748",
        "fName": None,
        "fSize": 0,
        "fPath": "https://docs.google.com/presentation/d/1qsL11PZssXMzXChY1vDiUfUjVtMsPkSHt1EZgZEU6OE/edit?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": 7,
        "label": "WeTalk Ppt"
      },
      {
        "uniqueID": "4530299940357623519",
        "fName": None,
        "fSize": 0,
        "fPath": "https://docs.google.com/spreadsheets/d/1IffEvQGbnkj6pUqafyxl34I_cjuU-2sMrBandV1glfM/edit?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": 7,
        "label": "Daily API Testing Reports"
      },
      {
        "uniqueID": "2010684754122457284",
        "fName": None,
        "fSize": 0,
        "fPath": "https://drive.google.com/file/d/17-KZMt4m4-RHUhzkZZWpcPyUejf09I-V/view?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": 7,
        "label": "OD"
      },
      {
        "uniqueID": "7814880563540938678",
        "fName": None,
        "fSize": 0,
        "fPath": "https://drive.google.com/file/d/15EZ5qO6GTvU7hPIdT9ZWDIRTg9Jh4QTV/view?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": 7,
        "label": "SVG"
      }
    ]
  },
  "dropBox": {
    "enabled": True,
    "files": [
      {
        "uniqueID": "8670003847332056822",
        "fName": None,
        "fSize": 0,
        "fPath": "https://www.dropbox.com/s/tywjhg1lvluo8vl/WeBox.pdf?dl=0",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "9",
        "label": "WeBox"
      },
      {
        "uniqueID": "1586751147798907997",
        "fName": None,
        "fSize": 0,
        "fPath": "https://www.dropbox.com/sh/9sirqndavlbv4lv/AACz95VSaVso9A_weDup3cwVa?dl=0",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "9",
        "label": "QA Team"
      },
      {
        "uniqueID": "5014251260363229112",
        "fName": None,
        "fSize": 0,
        "fPath": "https://www.dropbox.com/s/df49s38nvtjmnog/managing_securing_mobile_devices_9781119349846.pdf?dl=0",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "9",
        "label": "MDM"
      }
    ]
  },
  "s3Config": {
    "enabled": True,
    "identityPoolId": "us-west-2:9e8b7389-6218-4d4c-bca4-1768f3791613",
    "region": "us-west-2",
    "bucketName": [
      "laf-dev"
    ]
  }
}
AddingSDCardFolder={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 852,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": None,
  "passcodeInterval": "120000",
  "showLinks": True,
  "sdCard": {
    "enabled": True,
    "files": [
      {
        "uniqueID": "557035397307059925",
        "fName": None,
        "fSize": 0,
        "fPath": "Documents/Webox.pdf",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": 6,
        "label": "QA"
      },
      {
        "label": "Testing ",
        "fPath": "Documents/WeGuard.pdf",
        "fileType": 6
      }
    ]
  },
  "googleDrive": {
    "enabled": False,
    "files": [
      {
        "uniqueID": "3518706255667481656",
        "fName": None,
        "fSize": 0,
        "fPath": "https://docs.google.com/spreadsheets/d/1ivr53lYwNzWpeaxJ8sUMc4qNADGMtOuYGkuu2_dGSbA/edit?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "7",
        "label": "Work Profile Report"
      },
      {
        "uniqueID": "6950513484462702748",
        "fName": None,
        "fSize": 0,
        "fPath": "https://docs.google.com/presentation/d/1qsL11PZssXMzXChY1vDiUfUjVtMsPkSHt1EZgZEU6OE/edit?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "7",
        "label": "WeTalk Ppt"
      },
      {
        "uniqueID": "4530299940357623519",
        "fName": None,
        "fSize": 0,
        "fPath": "https://docs.google.com/spreadsheets/d/1IffEvQGbnkj6pUqafyxl34I_cjuU-2sMrBandV1glfM/edit?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "7",
        "label": "Daily API Testing Reports"
      },
      {
        "uniqueID": "2010684754122457284",
        "fName": None,
        "fSize": 0,
        "fPath": "https://drive.google.com/file/d/17-KZMt4m4-RHUhzkZZWpcPyUejf09I-V/view?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "7",
        "label": "OD"
      },
      {
        "uniqueID": "7814880563540938678",
        "fName": None,
        "fSize": 0,
        "fPath": "https://drive.google.com/file/d/15EZ5qO6GTvU7hPIdT9ZWDIRTg9Jh4QTV/view?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "7",
        "label": "SVG"
      }
    ]
  },
  "dropBox": {
    "enabled": False,
    "files": [
      {
        "uniqueID": "8670003847332056822",
        "fName": None,
        "fSize": 0,
        "fPath": "https://www.dropbox.com/s/tywjhg1lvluo8vl/WeBox.pdf?dl=0",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "9",
        "label": "WeBox"
      },
      {
        "uniqueID": "1586751147798907997",
        "fName": None,
        "fSize": 0,
        "fPath": "https://www.dropbox.com/sh/9sirqndavlbv4lv/AACz95VSaVso9A_weDup3cwVa?dl=0",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "9",
        "label": "QA Team"
      },
      {
        "uniqueID": "5014251260363229112",
        "fName": None,
        "fSize": 0,
        "fPath": "https://www.dropbox.com/s/df49s38nvtjmnog/managing_securing_mobile_devices_9781119349846.pdf?dl=0",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "9",
        "label": "MDM"
      }
    ]
  },
  "s3Config": {
    "enabled": True,
    "identityPoolId": "us-west-2:9e8b7389-6218-4d4c-bca4-1768f3791613",
    "region": "us-west-2",
    "bucketName": [
      "laf-dev"
    ]
  }
}
configwithoutsignpolicygroupfolders={
  "policyId": "5f27d3bcfce9664744139ae1",
  "s3Config": {
    "enabled": True,
    "identityPoolId": "",
    "region": "",
    "bucketName": []
  },
  "signEnabled": False,
  "uploadSizeLimit": "5000000"
}
configwithsignpolicygroupfolders={
  "policyId": "5f27d3bcfce9664744139ae1",
  "s3Config": {
    "enabled": True,
    "identityPoolId": "",
    "region": "",
    "bucketName": []
  },
  "signEnabled": True,
  "uploadSizeLimit": "5000000"
}
DeletingDropboxFolder={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 865,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": None,
  "passcodeInterval": "120000",
  "showLinks": True,
  "sdCard": {
    "enabled": True,
    "files": [
      {
        "uniqueID": "8116472784163521206",
        "fName": None,
        "fSize": 0,
        "fPath": "Documents/WeGuard.pdf",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "6",
        "label": "Testing "
      }
    ]
  },
  "googleDrive": {
    "enabled": True,
    "files": [
      {
        "uniqueID": "6950513484462702748",
        "fName": None,
        "fSize": 0,
        "fPath": "https://docs.google.com/presentation/d/1qsL11PZssXMzXChY1vDiUfUjVtMsPkSHt1EZgZEU6OE/edit?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "7",
        "label": "WeTalk Ppt"
      },
      {
        "uniqueID": "4530299940357623519",
        "fName": None,
        "fSize": 0,
        "fPath": "https://docs.google.com/spreadsheets/d/1IffEvQGbnkj6pUqafyxl34I_cjuU-2sMrBandV1glfM/edit?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "7",
        "label": "Daily API Testing Reports"
      },
      {
        "uniqueID": "2010684754122457284",
        "fName": None,
        "fSize": 0,
        "fPath": "https://drive.google.com/file/d/17-KZMt4m4-RHUhzkZZWpcPyUejf09I-V/view?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "7",
        "label": "OD"
      },
      {
        "uniqueID": "7814880563540938678",
        "fName": None,
        "fSize": 0,
        "fPath": "https://drive.google.com/file/d/15EZ5qO6GTvU7hPIdT9ZWDIRTg9Jh4QTV/view?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "7",
        "label": "SVG"
      }
    ]
  },
  "dropBox": {
    "enabled": True,
    "files": [
      {
        "uniqueID": "5014251260363229112",
        "fName": None,
        "fSize": 0,
        "fPath": "https://www.dropbox.com/s/df49s38nvtjmnog/managing_securing_mobile_devices_9781119349846.pdf?dl=0",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": 9,
        "label": "MDM"
      },
      {
        "uniqueID": "7761166636710774629",
        "fName": None,
        "fSize": 0,
        "fPath": "https://www.dropbox.com/s/tywjhg1lvluo8vl/WeBox.pdf?dl=0",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": 9,
        "label": "WeBox"
      }
    ]
  },
  "s3Config": {
    "enabled": True,
    "identityPoolId": "us-west-2:9e8b7389-6218-4d4c-bca4-1768f3791613",
    "region": "us-west-2",
    "bucketName": [
      "laf-dev"
    ]
  }
}
DeletingGoogleDriveFolder={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 865,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": None,
  "passcodeInterval": 120000,
  "showLinks": True,
  "sdCard": {
    "enabled": True,
    "files": [
      {
        "uniqueID": "8116472784163521206",
        "fName": None,
        "fSize": 0,
        "fPath": "Documents/WeGuard.pdf",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "6",
        "label": "Testing "
      }
    ]
  },
  "googleDrive": {
    "enabled": True,
    "files": [
      {
        "uniqueID": "6950513484462702748",
        "fName": None,
        "fSize": 0,
        "fPath": "https://docs.google.com/presentation/d/1qsL11PZssXMzXChY1vDiUfUjVtMsPkSHt1EZgZEU6OE/edit?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": 7,
        "label": "WeTalk Ppt"
      },
      {
        "uniqueID": "4530299940357623519",
        "fName": None,
        "fSize": 0,
        "fPath": "https://docs.google.com/spreadsheets/d/1IffEvQGbnkj6pUqafyxl34I_cjuU-2sMrBandV1glfM/edit?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": 7,
        "label": "Daily API Testing Reports"
      },
      {
        "uniqueID": "2010684754122457284",
        "fName": None,
        "fSize": 0,
        "fPath": "https://drive.google.com/file/d/17-KZMt4m4-RHUhzkZZWpcPyUejf09I-V/view?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": 7,
        "label": "OD"
      }
    ]
  },
  "dropBox": {
    "enabled": True,
    "files": [
      {
        "uniqueID": "5014251260363229112",
        "fName": None,
        "fSize": 0,
        "fPath": "https://www.dropbox.com/s/df49s38nvtjmnog/managing_securing_mobile_devices_9781119349846.pdf?dl=0",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "9",
        "label": "MDM"
      },
      {
        "uniqueID": "7761166636710774629",
        "fName": None,
        "fSize": 0,
        "fPath": "https://www.dropbox.com/s/tywjhg1lvluo8vl/WeBox.pdf?dl=0",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "9",
        "label": "WeBox"
      }
    ]
  },
  "s3Config": {
    "enabled": True,
    "identityPoolId": "us-west-2:9e8b7389-6218-4d4c-bca4-1768f3791613",
    "region": "us-west-2",
    "bucketName": [
      "laf-dev"
    ]
  }
}
DeletingSDCardFolder={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 853,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": None,
  "passcodeInterval": 120000,
  "showLinks": True,
  "sdCard": {
    "enabled": True,
    "files": [
      {
        "uniqueID": "8116472784163521206",
        "fName": None,
        "fSize": 0,
        "fPath": "Documents/WeGuard.pdf",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": 6,
        "label": "Testing "
      }
    ]
  },
  "googleDrive": {
    "enabled": False,
    "files": [
      {
        "uniqueID": "6950513484462702748",
        "fName": None,
        "fSize": 0,
        "fPath": "https://docs.google.com/presentation/d/1qsL11PZssXMzXChY1vDiUfUjVtMsPkSHt1EZgZEU6OE/edit?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "7",
        "label": "WeTalk Ppt"
      },
      {
        "uniqueID": "4530299940357623519",
        "fName": None,
        "fSize": 0,
        "fPath": "https://docs.google.com/spreadsheets/d/1IffEvQGbnkj6pUqafyxl34I_cjuU-2sMrBandV1glfM/edit?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "7",
        "label": "Daily API Testing Reports"
      },
      {
        "uniqueID": "2010684754122457284",
        "fName": None,
        "fSize": 0,
        "fPath": "https://drive.google.com/file/d/17-KZMt4m4-RHUhzkZZWpcPyUejf09I-V/view?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "7",
        "label": "OD"
      },
      {
        "uniqueID": "7814880563540938678",
        "fName": None,
        "fSize": 0,
        "fPath": "https://drive.google.com/file/d/15EZ5qO6GTvU7hPIdT9ZWDIRTg9Jh4QTV/view?usp=sharing",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "7",
        "label": "SVG"
      }
    ]
  },
  "dropBox": {
    "enabled": False,
    "files": [
      {
        "uniqueID": "1586751147798907997",
        "fName": None,
        "fSize": 0,
        "fPath": "https://www.dropbox.com/sh/9sirqndavlbv4lv/AACz95VSaVso9A_weDup3cwVa?dl=0",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "9",
        "label": "QA Team"
      },
      {
        "uniqueID": "5014251260363229112",
        "fName": None,
        "fSize": 0,
        "fPath": "https://www.dropbox.com/s/df49s38nvtjmnog/managing_securing_mobile_devices_9781119349846.pdf?dl=0",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "9",
        "label": "MDM"
      },
      {
        "uniqueID": "7761166636710774629",
        "fName": None,
        "fSize": 0,
        "fPath": "https://www.dropbox.com/s/tywjhg1lvluo8vl/WeBox.pdf?dl=0",
        "fCheckSum": None,
        "fExtension": None,
        "timestamp": 0,
        "fileType": "9",
        "label": "WeBox"
      }
    ]
  },
  "s3Config": {
    "enabled": True,
    "identityPoolId": "us-west-2:9e8b7389-6218-4d4c-bca4-1768f3791613",
    "region": "us-west-2",
    "bucketName": [
      "laf-dev"
    ]
  }
}
disabledallowdownload={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 310,
  "allowDownload": False,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": True,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": "123456",
  "passcodeInterval": 120000,
  "showLinks": True,
  "sdCard": {
    "enabled": True,
    "files": None
  },
  "googleDrive": {
    "enabled": True,
    "files": None
  },
  "dropBox": {
    "enabled": True,
    "files": None
  },
  "s3Config": {
    "enabled": True,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}
disabledallowfileview={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 13,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": False,
  "allowDownloadOnlyOnWiFi": True,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": "123456",
  "passcodeInterval": 120000,
  "showLinks": True,
  "sdCard": {
    "enabled": True,
    "files": None
  },
  "googleDrive": {
    "enabled": True,
    "files": None
  },
  "dropBox": {
    "enabled": True,
    "files": None
  },
  "s3Config": {
    "enabled": True,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}
DisabledGoogleDriveDropbox={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 853,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": False,
  "allowDownloadOnlyOnWiFi": True,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": "123456",
  "passcodeInterval": 120000,
  "showLinks": True,
  "sdCard": {
    "enabled": True,
    "files": None
  },
  "googleDrive": {
    "enabled": False,
    "files": None
  },
  "dropBox": {
    "enabled": False,
    "files": None
  },
  "s3Config": {
    "enabled": True,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}
disabledopenwith={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 13,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": True,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": False,
  "passcode": "123456",
  "passcodeInterval": 120000,
  "showLinks": True,
  "sdCard": {
    "enabled": True,
    "files": None
  },
  "googleDrive": {
    "enabled": False,
    "files": None
  },
  "dropBox": {
    "enabled": False,
    "files": None
  },
  "s3Config": {
    "enabled": True,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}
DisabledSDcardAmazonS3={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 853,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": True,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": "123456",
  "passcodeInterval": 120000,
  "showLinks": True,
  "sdCard": {
    "enabled": False,
    "files": None
  },
  "googleDrive": {
    "enabled": True,
    "files": None
  },
  "dropBox": {
    "enabled": True,
    "files": None
  },
  "s3Config": {
    "enabled": False,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}
disabledservicetypes={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 13,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": True,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": "123456",
  "passcodeInterval": 120000,
  "showLinks": True,
  "sdCard": {
    "enabled": False,
    "files": None
  },
  "googleDrive": {
    "enabled": False,
    "files": None
  },
  "dropBox": {
    "enabled": False,
    "files": None
  },
  "s3Config": {
    "enabled": False,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}
disabledshowlinks={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 13,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": True,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": "123456",
  "passcodeInterval": 120000,
  "showLinks": False,
  "sdCard": {
    "enabled": True,
    "files": None
  },
  "googleDrive": {
    "enabled": True,
    "files": None
  },
  "dropBox": {
    "enabled": True,
    "files": None
  },
  "s3Config": {
    "enabled": False,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}
disabledweboxpasscode={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 13,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": True,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": None,
  "passcodeInterval": 120000,
  "showLinks": False,
  "sdCard": {
    "enabled": False,
    "files": None
  },
  "googleDrive": {
    "enabled": False,
    "files": None
  },
  "dropBox": {
    "enabled": False,
    "files": None
  },
  "s3Config": {
    "enabled": False,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}
enabledallowdownload={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 13,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": False,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": False,
  "passcode": None,
  "passcodeInterval": 120000,
  "showLinks": False,
  "sdCard": {
    "enabled": False,
    "files": None
  },
  "googleDrive": {
    "enabled": False,
    "files": None
  },
  "dropBox": {
    "enabled": False,
    "files": None
  },
  "s3Config": {
    "enabled": False,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}
enabledfileview={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 13,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": False,
  "passcode": None,
  "passcodeInterval": 120000,
  "showLinks": False,
  "sdCard": {
    "enabled": False,
    "files": None
  },
  "googleDrive": {
    "enabled": False,
    "files": None
  },
  "dropBox": {
    "enabled": False,
    "files": None
  },
  "s3Config": {
    "enabled": False,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}
enabledopenwith={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 13,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": False,
  "passcode": None,
  "passcodeInterval": 120000,
  "showLinks": False,
  "sdCard": {
    "enabled": False,
    "files": None
  },
  "googleDrive": {
    "enabled": False,
    "files": None
  },
  "dropBox": {
    "enabled": False,
    "files": None
  },
  "s3Config": {
    "enabled": False,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}
enableds3sdcard={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 13,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": None,
  "passcodeInterval": 120000,
  "showLinks": False,
  "sdCard": {
    "enabled": True,
    "files": None
  },
  "googleDrive": {
    "enabled": False,
    "files": None
  },
  "dropBox": {
    "enabled": False,
    "files": None
  },
  "s3Config": {
    "enabled": True,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}
enabledservicetypes={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 13,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": None,
  "passcodeInterval": 120000,
  "showLinks": False,
  "sdCard": {
    "enabled": True,
    "files": None
  },
  "googleDrive": {
    "enabled": True,
    "files": None
  },
  "dropBox": {
    "enabled": True,
    "files": None
  },
  "s3Config": {
    "enabled": True,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}
enabledshowlinks={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 13,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": None,
  "passcodeInterval": 120000,
  "showLinks": True,
  "sdCard": {
    "enabled": True,
    "files": None
  },
  "googleDrive": {
    "enabled": True,
    "files": None
  },
  "dropBox": {
    "enabled": True,
    "files": None
  },
  "s3Config": {
    "enabled": True,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}
enabledweboxpasscode={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 13,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": "123456",
  "passcodeInterval": 120000,
  "showLinks": False,
  "sdCard": {
    "enabled": True,
    "files": None
  },
  "googleDrive": {
    "enabled": True,
    "files": None
  },
  "dropBox": {
    "enabled": True,
    "files": None
  },
  "s3Config": {
    "enabled": True,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}
enableddrivedropbox={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 13,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": True,
  "allowFileView": True,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": True,
  "passcode": None,
  "passcodeInterval": 120000,
  "showLinks": True,
  "sdCard": {
    "enabled": False,
    "files": None
  },
  "googleDrive": {
    "enabled": True,
    "files": None
  },
  "dropBox": {
    "enabled": True,
    "files": None
  },
  "s3Config": {
    "enabled": False,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}

noWeBoxConfigs={
  "id": "5e69cc0f77f85d7c96b0d9d7",
  "deleted": False,
  "version": 310,
  "policyId": "5f27d3bcfce9664744139ae1",
  "allowDownload": False,
  "allowFileView": False,
  "allowDownloadOnlyOnWiFi": False,
  "allowDownloadOnNetwork": False,
  "allowDownloadOnNWWiFI": True,
  "openWith": False,
  "passcode": None,
  "passcodeInterval": 120000,
  "showLinks": False,
  "sdCard": {
    "enabled": False,
    "files": None
  },
  "googleDrive": {
    "enabled": False,
    "files": None
  },
  "dropBox": {
    "enabled": False,
    "files": None
  },
  "s3Config": {
    "enabled": False,
    "identityPoolId": None,
    "region": None,
    "bucketName": None
  }
}

undosave={
  "topic": "webox"+ "_"+ globalvar.actcode + "_" + globalvar.pactcode,
  "type": "FILES_UPDATE",
  "message": "WeBox msg",
  "isLicenseLevel": True,
  "actCode": "Q6Y5Q",
  "pActCode": "LOST-UVYTK"
}

logout={
  "agent": "PORTAL",
  "actorId": globalvar.userName,
  "policyId": None,
  "type": "Info",
  "msg": "Logged out",
  "action": "-",
  "event": "Logout",
  "sentTime": start_timestamp,
  "sourceIP": ""
}