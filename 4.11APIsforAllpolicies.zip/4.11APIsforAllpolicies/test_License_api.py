import json
import pytest
import requests
import group_globalVar as globalvar
import cases_validations as config
import globalVariables as globalcheck
import WeGuardlogger as WeGuard

def url_formatter(psize, page):
    url = "enterprise/rest/weguard-v2/license?pageSize={pagize}&page={page}".format(pagize=psize, page=page)
    return url

@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(config.run_test_001_license_10000 == 0, reason="test skipped")
@pytest.mark.usualtest
@pytest.mark.devicespage
@pytest.mark.sanitytest
@pytest.mark.regressiontest
@pytest.mark.positivetest
@pytest.mark.run(order=10012)
def test_tc_001_LicenseAPI(url):
    if globalvar.bearerToken == '':
        pytest.skip("Empty Bearer token Skipping test")
    try :
        LicenseUrl = url_formatter(globalcheck.pagesize_10000, globalcheck.page_1)
        # LicenseUrl = "enterprise/rest/weguard-v2/license?pageSize=10000&page=1"
        apiUrl = globalvar.BaseURL + LicenseUrl
        header = 'Bearer' + ' ' + globalvar.bearerToken
        res = requests.get(url=apiUrl, headers={'Authorization': header})
        resp_body = res.json()
        WeGuard.logger.debug(resp_body)
        json_resp = json.loads(res.content)
        WeGuard.logger.debug(json_resp.keys())
        android_policies = json_resp.get('entity').get('response')
        ios_profiles = json_resp.get('entity').get('iosProfile')
        profiletype = []
        profileid = []
        #to get profile ids based on policy type
        for profile in ios_profiles:
            profiletype.append(profile.get('type'))
            profileid.append(profile.get('id'))
        merged_list = [(profiletype[i], profileid[i]) for i in range(0, len(profiletype))]
        for key, value in merged_list:
            if key == 'IOS_NONDEP':
                globalcheck.nondepProfileIds.append(value)
            else:
                globalcheck.depProfileIds.append(value)
        #to get policy ids based on policy type
        globalcheck.policytype = []
        policyid = []
        for policy in android_policies:
            globalcheck.policytype.append(policy.get('type'))
            policyid.append(policy.get('id'))
        merged_list = [(globalcheck.policytype[i], policyid[i]) for i in range(0, len(globalcheck.policytype))]
        for key, value in merged_list:
            if key == 'ANDROID_KIOSK':
                globalcheck.kioskIds.append(value)
            elif key == 'ANDROID_WM':
                globalcheck.wmIds.append(value)
            else:
                globalcheck.wpIds.append(value)
        #to get android policy id
        for policy in android_policies:
            globalcheck.android_policy_id.append(policy.get('id'))
        #to get android policy names
        for policy in android_policies:
            globalcheck.android_policyname.append(policy.get('name'))
        #to get ios profile names
        for policy in ios_profiles:
            globalcheck.iOS_Profile_name.append(policy.get('name'))
        assert res.status_code == 200
    except BaseException as e:
        WeGuard.logger.debug(e)
        assert False

