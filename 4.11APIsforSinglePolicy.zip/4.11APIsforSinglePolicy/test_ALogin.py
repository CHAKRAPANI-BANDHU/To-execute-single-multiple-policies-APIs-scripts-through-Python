import json
import pytest
import requests
from datetime import datetime
import group_globalVar as globalvar
import Executor
import WeGuardlogger as WeGuard
import test_GETutils as utils

LoginURL= 'enterprise/rest/users/login'

@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_000001_AccountAdmin_Invalid_Credentials == 0, reason="Login with Invalid Credentials")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.raretest
@pytest.mark.sanitytest
@pytest.mark.regressiontest
@pytest.mark.negativetest
@pytest.mark.run(order=10001)
def test_tc_000002_Invalid_Credentials(url):
    print("\n\n--------------------------- TC 000001 Login With Invalid Credentails Start ---------------------------")
    now1 =datetime.now()
    try:
        apiUrl = globalvar.BaseURL + LoginURL
        jsonData = {
            'userName': globalvar.userName,
            'password': '123456@Pass'
        }
        res = requests.post(url=apiUrl, json=jsonData, timeout=globalvar.timeout)
        curl_str1 = utils.getCurlEquivalent(res)
        print(curl_str1)
        WeGuard.logger.warning("\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + " Response Headers: " + str(res.headers) + "\n Response: " + str(res.content))
        WeGuard.logger.warning("\n\n--------------------------- TC 000001 Login With Invalid Credentails PASS ---------------------------\n\n")
        assert res.status_code == 200
    except BaseException as e:
        now2 = datetime.now()
        WeGuard.logger.warning("Time taken: " + str(now2 - now1))
        WeGuard.logger.error("\n\n--------------------------- TC 000001 Login with Invalid Credentials FAIL ---------------------------\n\n")
        WeGuard.logger.error('Error at %s', 'BaseException',exc_info=e)
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_000001_AccountAdmin_Invalid_Email == 0, reason="Login with Invalid Email")
@pytest.mark.negativetest
@pytest.mark.run(order=10002)
def test_tc_000003_Invalid_Email(url):
    print("\n\n--------------------------- TC 000001 Login With Invalid Email Start---------------------------")
    now1 =datetime.now()
    try:
        apiUrl = globalvar.BaseURL + LoginURL
        jsonData = {
            'userName': "@.it",
            'password': globalvar.password
        }
        res = requests.post(url=apiUrl, json=jsonData, timeout=globalvar.timeout)
        curl_str1 = utils.getCurlEquivalent(res)
        print(curl_str1)
        WeGuard.logger.warning("\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + " Response Headers: " + str(res.headers) + "\n Response: " + str(res.content))
        WeGuard.logger.warning("\n\n--------------------------- TC 000001 Login With Invalid Email PASS ---------------------------\n\n")
        assert res.status_code == 200
    except BaseException as e:
        now2 = datetime.now()
        WeGuard.logger.warning("Time taken: " + str(now2 - now1))
        WeGuard.logger.error("\n\n--------------------------- TC 000001 Login with Invalid Email FAIL ---------------------------\n\n")
        WeGuard.logger.error('Error at %s', 'BaseException',exc_info=e)

@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_000001_AccountAdmin_Invalid_Password == 0, reason="Login with Invalid Password")
@pytest.mark.negativetest
@pytest.mark.run(order=10003)
def test_tc_000004_Invalid_Password(url):
    print("\n\n--------------------------- TC 000001 Login With Invalid Password Start---------------------------")
    now1 =datetime.now()
    try:
        apiUrl = globalvar.BaseURL + LoginURL
        jsonData = {
            'userName': globalvar.userName,
            'password': "Pass@123"
        }
        res = requests.post(url=apiUrl, json=jsonData, timeout=globalvar.timeout)
        curl_str1 = utils.getCurlEquivalent(res)
        print(curl_str1)
        WeGuard.logger.warning("\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + " Response Headers: " + str(res.headers) + "\n Response: " + str(res.content))
        WeGuard.logger.warning("--------------------------- TC 000001 Login With Invalid Password PASS ---------------------------\n\n")
        assert res.status_code == 200
    except BaseException as e:
        now2 = datetime.now()
        WeGuard.logger.warning("Time taken: " + str(now2 - now1))
        WeGuard.logger.error("--------------------------- TC 000001 Login with Invalid Password FAIL ---------------------------\n\n")
        WeGuard.logger.error('Error at %s', 'BaseException',exc_info=e)

@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_000001_AccountAdmin_Credentials_With_Spaces == 0, reason="Login with Spaces in Credentials Test is skipped")
@pytest.mark.negativetest
@pytest.mark.run(order=10004)
def test_tc_000005_Credentials_With_Spaces(url):
    print("--------------------------- TC 000001 Login With Credentials with Spaces Start---------------------------")
    now1 =datetime.now()
    try:
        apiUrl = globalvar.BaseURL + LoginURL
        jsonData = {
            'userName': " ",
            'password': " "
        }
        res = requests.post(url=apiUrl, json=jsonData, timeout=globalvar.timeout)
        curl_str1 = utils.getCurlEquivalent(res)
        print(curl_str1)
        WeGuard.logger.warning("\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + " Response Headers: " + str(res.headers) + "\n Response: " + str(res.content))
        WeGuard.logger.warning("--------------------------- TC 000001 Login With Credentails with Spaces PASS ---------------------------\n\n")
        assert res.status_code == 200
    except BaseException as e:
        now2 = datetime.now()
        WeGuard.logger.warning("Time taken: " + str(now2 - now1))
        WeGuard.logger.error("--------------------------- TC 000001 Login with Credentails with Spaces  FAIL ---------------------------\n\n")
        WeGuard.logger.error('Error at %s', 'BaseException',exc_info=e)

@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_000001_AccountAdmin_WithOut_Password == 0, reason="Login without Password Test is skipped")
@pytest.mark.negativetest
@pytest.mark.run(order=10005)
def test_tc_000005_WithOut_Password(url):
    print("--------------------------- TC 000001 Login Without Password Start---------------------------")
    now1 =datetime.now()
    try:
        apiUrl = globalvar.BaseURL + LoginURL
        jsonData ={
            'userName': globalvar.userName,
            'password': ""
        }
        res = requests.post(url=apiUrl, json=jsonData, timeout=globalvar.timeout)
        curl_str1 = utils.getCurlEquivalent(res)
        print(curl_str1)
        WeGuard.logger.warning("\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + " Response Headers: " + str(res.headers) + "\n Response: " + str(res.content))
        WeGuard.logger.warning("--------------------------- TC 000001 Login Without Password PASS ---------------------------\n\n")
        assert res.status_code == 200
    except BaseException as e:
        now2 = datetime.now()
        WeGuard.logger.warning("Time taken: " + str(now2 - now1))
        WeGuard.logger.error("--------------------------- TC 000001 Login Without Password  FAIL ---------------------------\n\n")
        WeGuard.logger.error('Error at %s', 'BaseException',exc_info=e)

@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_000001_AccountAdmin_WithOut_UserName == 0, reason="Login without User Name Test is skipped")
@pytest.mark.negativetest
@pytest.mark.run(order=10006)
def test_tc_000006_WithOut_UserName(url):
    print("--------------------------- TC 000001 Login Without User Name Start---------------------------")
    now1 =datetime.now()
    try:
        apiUrl = globalvar.BaseURL + LoginURL
        jsonData = {
            'userName': "",
            'password': "pass@1"
        }
        res = requests.post(url=apiUrl, json=jsonData, timeout=globalvar.timeout)
        curl_str1 = utils.getCurlEquivalent(res)
        print(curl_str1)
        WeGuard.logger.warning("\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + " Response Headers: " + str(res.headers) + "\n Response: " + str(res.content))
        WeGuard.logger.warning("--------------------------- TC 000001 Login Without User Name PASS ---------------------------\n\n")
        assert res.status_code == 200
    except BaseException as e:
        now2 = datetime.now()
        WeGuard.logger.warning("Time taken: " + str(now2 - now1))
        WeGuard.logger.error("--------------------------- TC 000001 Login Without User Name  FAIL ---------------------------\n\n")
        WeGuard.logger.error('Error at %s', 'BaseException',exc_info=e)

@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_000001_AccountAdmin_WithOut_UserName_Password == 0, reason="Login without Username and Password")
@pytest.mark.negativetest
@pytest.mark.run(order=10007)
def test_tc_000007_WithOut_UserName_Password(url):
    print("--------------------------- TC 000001 Login Without User Name and Password Start ---------------------------")
    now1 =datetime.now()
    try:
        apiUrl = globalvar.BaseURL + LoginURL
        jsonData ={
            'userName': "",
            'password': ""
        }
        res = requests.post(url=apiUrl, json=jsonData, timeout=globalvar.timeout)
        curl_str1 = utils.getCurlEquivalent(res)
        print(curl_str1)
        WeGuard.logger.warning("\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + " Response Headers: " + str(res.headers) + "\n Response: " + str(res.content))
        WeGuard.logger.warning("--------------------------- TC 000001 Login Without User Name and Password PASS ---------------------------\n\n")
        assert res.status_code == 200
    except BaseException as e:
        now2 = datetime.now()
        WeGuard.logger.warning("Time taken: " + str(now2 - now1))
        WeGuard.logger.error("--------------------------- TC 000001 Login Without User Name and Password FAIL ---------------------------\n\n")
        WeGuard.logger.error('Error at %s', 'BaseException',exc_info=e)

@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_000001_AccountAdmin_login == 0 , reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.negativetest
@pytest.mark.run(order=10008)
def test_tc_000001_validloginCredentials(url):
    print("\n\n--------------------------- TC 000001 Login Start ---------------------------")
    now1 =datetime.now()
    try:
        apiUrl = globalvar.BaseURL + LoginURL
        jsonData = {
            'userName': globalvar.userName,
            'password': globalvar.password
        }
        res = requests.post(url=apiUrl, json=jsonData, timeout=globalvar.timeout)
        curl_str1 = utils.getCurlEquivalent(res)
        print(curl_str1)
        print(res.content)
        WeGuard.logger.warning("\n" + " Response code: " + str(res.status_code) + " apiUrl: " + apiUrl + " Response headers: " + str(res.headers) + "\n" + " Request Response: " + str(res.content))
        globalvar.bearerToken = res.headers.get(globalvar.bearerToken)
        globalvar.email = json.loads(res.content.decode()).get('userName')
        globalvar.loggedInUserId = json.loads(res.content)
        globalvar.bearerToken = json.loads(res.content)['entity']['jwtToken']
        globalvar.actcode = json.loads(res.content)['entity']['activationCode']
        globalvar.pactcode = json.loads(res.content)['entity']['productActivationCode']
        globalvar.fname = json.loads(res.content)['entity']['fName']
        globalvar.lname = json.loads(res.content)['entity']['lName']
        globalvar.accountId = json.loads(res.content)['entity']['userData']['accountInfo']['id']
        #WeGuard.logger.warning("JWT token is :" + globalvar.bearerToken)
        assert globalvar.bearerToken != ''
        assert globalvar.userName == globalvar.userName
        WeGuard.logger.warning("\n\n--------------------------- TC 000001 Login PASS ---------------------------\n\n")
        assert res.status_code == 200
    except BaseException as e:
        now2 = datetime.now()
        WeGuard.logger.warning("Time taken: " + str(now2 - now1))
        WeGuard.logger.error("\n\n--------------------------- TC 000001 Login FAIL ---------------------------\n\n")
        WeGuard.logger.error('Error at %s', 'BaseException',exc_info=e)
