from datetime import datetime
import pytest
import requests
import group_globalVar as globalvar
import test_GETutils as utils
import globalVariables as globals
import WeGuardlogger as WeGuard
import Executor
import WeBoxpayloadinfo as variable
import json

def url_formatter(accountId, start, end, page, size):
     url = "notification/rest/alert/account/{accountId}?start={start}&end={end}&page={page}&size={size}".format(accountId=accountId, start=start, end=end, page=page, size=size)
     return url

def url_formatter2(accountId, start, end, page, size, type, level):
    url2 = "notification/rest/alert/account/{accountId}?start={start}&end={end}&page={page}&size={size}&type={type}&level={level}".format(accountId=accountId, start=start, end=end, page=page, size=size, type=type,level=level)
    return url2

def url_formatter3(accountId, start, end, page, size, type):
    url3 = "notification/rest/alert/account/{accountId}?start={start}&end={end}&page={page}&size={size}&type={type}".format(accountId=accountId, start=start, end=end, page=page, size=size, type=type)
    return url3
def url_formatter4(accountId, start, end, page, size, level, ack):
    url4 = "notification/rest/alert/account/{accountId}?start={start}&end={end}&page={page}&size={size}&level={level}&ack={ack}".format(accountId=accountId, start=start, end=end, page=page, size=size, level=level, ack=ack)
    return url4
def url_formatter5(accountId,read):
    url5 = "notification/rest/alert/account/{accountId}/{read}".format(accountId=accountId, read=read)
    return url5


# GET method to get crtical alerts that are not acknowledged by use after clicking on Alert notification icon
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_UnAckCriticalAlerts == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10448)
def test_tc_000001_UnacknowledgedCriticalAlerts(url):
 now1 =datetime.now()
 if globalvar.bearerToken == '':
     pytest.skip("Empty Bearer token. Skipping test")
 try:
     UnacknowledgedCriticalAlerts = url_formatter4(globalvar.accountId, variable.isomonth, variable.isoend, globals.page_1, globals.pagesize_10, 'CRITICAL', 'unread')
     apiUrl = globalvar.BaseURL + UnacknowledgedCriticalAlerts
     Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
     res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
     curl_str1 = utils.getCurlEquivalent(res)
     print(curl_str1)
     print(res.content)
     WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
     variable.ackalerts = json.loads(res.content)['entity']['list']
     ackalerts = []
     for alerts in ackalerts:
           ackalerts.append(alerts.get('id'))
     variable.ackalerts = ackalerts
     print("\n\n--------------------------- Displaying Unacknowledged Critical Alerts all alert types and levels ---------------------------")
     assert res.status_code == 200
 except BaseException as e:
     WeGuard.logger.error('Error at %s', 'BaseException', exc_info=e)
     now2 = datetime.now()
     WeGuard.logger.warning("Time taken: " + str(now2 - now1))
     print("\n\n--------------------------- Not displaying Unacknowledged Critical Alerts all alert types and levels ---------------------------\n\n")
     assert False
# GET method to GET all level and types alert notifications of Todays
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_TodaysAlerts == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10403)
def test_tc_000001_AlertsTypesLevelAll(url):
 now1 =datetime.now()
 if globalvar.bearerToken == '':
     pytest.skip("Empty Bearer token. Skipping test")
 try:
     AlertsTypesLevelAll = url_formatter(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10)
     apiUrl = globalvar.BaseURL + AlertsTypesLevelAll
     Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
     res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
     curl_str1 = utils.getCurlEquivalent(res)
     print(curl_str1)
     print(res.content)
     WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
     print("\n\n--------------------------- Displaying Todays all alert types and levels ---------------------------")
     assert res.status_code == 200
 except BaseException as e:
     WeGuard.logger.error('Error at %s', 'BaseException', exc_info=e)
     now2 = datetime.now()
     WeGuard.logger.warning("Time taken: " + str(now2 - now1))
     print("\n\n--------------------------- Not displaying all alert types and levels ---------------------------\n\n")
     assert False
# PUT method for Acknowledge
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AcknowledgingAlerts == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10403)
def test_tc_000001_AcknowledgingAlerts(url):
 now1 =datetime.now()
 if globalvar.bearerToken == '':
     pytest.skip("Empty Bearer token. Skipping test")
 try:
     AcknowledgedAlerts = url_formatter5(globalvar.accountId, 'read')
     apiUrl = globalvar.BaseURL + AcknowledgedAlerts
     Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
     res = requests.put(url=apiUrl, headers=Headers, json=variable.ackalerts, timeout=globalvar.timeout)
     curl_str1 = utils.getCurlEquivalent(res)
     print(curl_str1)
     print(res.content)
     WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
     print("\n\n--------------------------- Acknowledged Alerts ---------------------------")
     assert res.status_code == 200
 except BaseException as e:
     WeGuard.logger.error('Error at %s', 'BaseException', exc_info=e)
     now2 = datetime.now()
     WeGuard.logger.warning("Time taken: " + str(now2 - now1))
     print("\n\n--------------------------- Failed to Acknowledge Alerts ---------------------------\n\n")
     assert False
# GET method to GET all level and types alert notifications of Yesterday's
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_YesterdaysAlerts == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10444)
def test_tc_000001_YesterdaysAlertsTypesLevelAll(url):
 now1 =datetime.now()
 if globalvar.bearerToken == '':
     pytest.skip("Empty Bearer token. Skipping test")
 try:
     AlertsTypesLevelAllYesterday = url_formatter(globalvar.accountId, variable.isoyesterday, variable.isoend, globals.page_1, globals.pagesize_10)
     apiUrl = globalvar.BaseURL + AlertsTypesLevelAllYesterday
     Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
     res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
     curl_str1 = utils.getCurlEquivalent(res)
     print(curl_str1)
     print(res.content)
     WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
     print("\n\n--------------------------- Displaying Yesterday's all alert types and levels ---------------------------")
     assert res.status_code == 200
 except BaseException as e:
     WeGuard.logger.error('Error at %s', 'BaseException', exc_info=e)
     now2 = datetime.now()
     WeGuard.logger.warning("Time taken: " + str(now2 - now1))
     print("\n\n--------------------------- Not displaying all alert types and levels ---------------------------\n\n")
     assert False
# GET method to GET all level and types alert notifications of Custom Date Range
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_CustomDateRangeAlerts == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10445)
def test_tc_000001_CustomDateRangeAlertsTypesLevelAll(url):
 now1 =datetime.now()
 if globalvar.bearerToken == '':
     pytest.skip("Empty Bearer token. Skipping test")
 try:
     AlertsTypesLevelAllCustomDateRange = url_formatter(globalvar.accountId, variable.isocustom, variable.isoend, globals.page_1, globals.pagesize_10)
     apiUrl = globalvar.BaseURL + AlertsTypesLevelAllCustomDateRange
     Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
     res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
     curl_str1 = utils.getCurlEquivalent(res)
     print(curl_str1)
     print(res.content)
     WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
     print("\n\n--------------------------- Displaying Custom Date Range all alert types and levels ---------------------------")
     assert res.status_code == 200
 except BaseException as e:
     WeGuard.logger.error('Error at %s', 'BaseException', exc_info=e)
     now2 = datetime.now()
     WeGuard.logger.warning("Time taken: " + str(now2 - now1))
     print("\n\n--------------------------- Not displaying all alert types and levels ---------------------------\n\n")
     assert False
# GET method to GET Alert notifications of type=Battery and level=Low
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_Battery_Low == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10404)
def test_tc_000001_BatteryLow(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      BatteryLowAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'BATTERY', 'LOW')
      apiUrl = globalvar.BaseURL + BatteryLowAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=Battery and level=Low ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=Battery and level=Low ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=Battery and level=Warning
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_Battery_Warning == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10405)
def test_tc_000001_BatteryWarning(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      BatteryWarningAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'BATTERY', 'WARNING')
      apiUrl = globalvar.BaseURL + BatteryWarningAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.warning("\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + " \n Response headers: " + str(res.headers) + "\n Request Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=Battery and level=Warning ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=Battery and level=Warning ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=Battery and level=Critical
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_Battery_Critical == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10406)
def test_tc_000001_BatteryCritical(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      BatteryCriticalAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'BATTERY', 'CRITICAL')
      apiUrl = globalvar.BaseURL + BatteryCriticalAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=Battery and level=Critical ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=Battery and level=Critical ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DATA_USAGE and level=Low
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DATA_USAGE_Low == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10407)
def test_tc_000001_DATA_USAGE_Low(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DataUsageLowAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DATA_USAGE', 'LOW')
      apiUrl = globalvar.BaseURL + DataUsageLowAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=Battery and level=Low ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=Battery and level=Low ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DATA_USAGE and level=Warning
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DATA_USAGE_Warning == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10408)
def test_tc_000001_DATA_USAGEWarning(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DataUsageWarningAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DATA_USAGE', 'WARNING')
      apiUrl = globalvar.BaseURL + DataUsageWarningAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=Battery and level=Warning ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=Battery and level=Warning ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DATA_USAGE and level=Critical
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DATA_USAGE_Critical == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10409)
def test_tc_000001_DATA_USAGECritical(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DataUsageCriticalAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DATA_USAGE', 'CRITICAL')
      apiUrl = globalvar.BaseURL + DataUsageCriticalAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DATA_USAGE and level=Critical ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DATA_USAGE and level=Critical ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=KIOSK_LOCKED and level=ALL
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_KIOSK_LOCKED_ALL == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10410)
def test_tc_000001_KIOSK_LOCKED_Low(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      KioskLockedAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'KIOSK_LOCKED', 'ALL')
      apiUrl = globalvar.BaseURL + KioskLockedAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=KIOSK_LOCKED and level=ALL ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=KIOSK_LOCKED and level=ALL ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=KIOSK_UNLOCKED and level=Critical
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_KIOSK_UNLOCKED_Critical == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10411)
def test_tc_000001_KIOSK_UNLOCKED_Low(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      KioskUnlockedCriticalAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'KIOSK_UNLOCKED', 'CRITICAL')
      apiUrl = globalvar.BaseURL + KioskUnlockedCriticalAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=KIOSK_UNLOCKED and level=Critical ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=KIOSK_UNLOCKED and level=Critical ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=Admin_LOCKED and level=Critical
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_ADMIN_LOCKED_Critical == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10412)
def test_tc_000001_ADMIN_LOCKEDCritical(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      AdminLockedCriticalAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'ADMIN_LOCKED', 'CRITICAL')
      apiUrl = globalvar.BaseURL + AdminLockedCriticalAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=ADMIN_LOCKED and level=Critical ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=ADMIN_LOCKED and level=Critical ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DEVICE_REBOOTED and level=ALL
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_REBOOTED == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10413)
def test_tc_000001_DEVICE_REBOOTED_Low(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DeviceRebootedAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_REBOOTED', 'ALL')
      apiUrl = globalvar.BaseURL + DeviceRebootedAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_REBOOTED and level=Low ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_REBOOTED and level=Low ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DEVICE_WIPED and level=ALL
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_WIPED == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10414)
def test_tc_000001_DEVICE_WIPED_Low(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DeviceWipedAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_WIPED', 'ALL')
      apiUrl = globalvar.BaseURL + DeviceWipedAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_WIPED and level=ALL ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_WIPED and level=ALL ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DEVICE_DELETED and level=Critical
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_DELETED_Critical == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10415)
def test_tc_000001_DEVICE_DELETED_Low(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DeviceDeletedCriticalAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_DELETED', 'CRITICAL')
      apiUrl = globalvar.BaseURL + DeviceDeletedCriticalAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_DELETED and level=Critical ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_DELETED and level=Critical ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=ROOTED_ENROLL and level=Critical
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_ROOTED_ENROLL_Critical == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10416)
def test_tc_000001_ROOTED_ENROLL_Low(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      RootedDeviceEnrollCriticalAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'ROOTED_ENROLL', 'ALL')
      apiUrl = globalvar.BaseURL + RootedDeviceEnrollCriticalAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=ROOTED_ENROLL and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=ROOTED_ENROLL and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=MEMORY_ALERT and level=Low
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_MEMORY_ALERT_Low == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10417)
def test_tc_000001_MEMORY_ALERT_Low(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      MemoryLowAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'MEMORY_ALERT', 'LOW')
      apiUrl = globalvar.BaseURL + MemoryLowAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=MEMORY_ALERT and level=Low ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=MEMORY_ALERT and level=Low ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=MEMORY_ALERT and level=Warning
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_MEMORY_ALERT_Warning == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10418)
def test_tc_000001_MEMORY_ALERTWarning(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      MemoryWarningAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'MEMORY_ALERT', 'WARNING')
      apiUrl = globalvar.BaseURL + MemoryWarningAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=MEMORY_ALERT and level=Warning ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=MEMORY_ALERT and level=Warning ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=MEMORY_ALERT and level=Critical
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_MEMORY_ALERT_Critical == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10419)
def test_tc_000001_MEMORY_ALERTCritical(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      MemoryCriticalAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'MEMORY_ALERT', 'CRITICAL')
      apiUrl = globalvar.BaseURL + MemoryCriticalAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=MEMORY_ALERT and level=Critical ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=MEMORY_ALERT and level=Critical ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DISC_USAGE and level=Low
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DISC_USAGE_Low == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10420)
def test_tc_000001_DISC_USAGE_Low(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DiscUsageLowAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DISC_USAGE', 'LOW')
      apiUrl = globalvar.BaseURL + DiscUsageLowAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DISC_USAGE and level=Low ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DISC_USAGE and level=Low ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DISC_USAGE and level=Warning
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DISC_USAGE_Warning == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10421)
def test_tc_000001_DISC_USAGEWarning(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DiscUsageWarningAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DISC_USAGE', 'WARNING')
      apiUrl = globalvar.BaseURL + DiscUsageWarningAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DISC_USAGE and level=Warning ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DISC_USAGE and level=Warning ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DISC_USAGE and level=Critical
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DISC_USAGE_Critical == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10422)
def test_tc_000001_DISC_USAGECritical(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DiscUsageCriticalAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DISC_USAGE', 'CRITICAL')
      apiUrl = globalvar.BaseURL + DiscUsageCriticalAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DISC_USAGE and level=Critical ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DISC_USAGE and level=Critical ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DEVICE_FALLEN and level=Critical
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_FALLEN_Critical == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10423)
def test_tc_000001_DEVICE_FALLEN_Low(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DeviceFallenCriticalAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_FALLEN', 'LOW')
      apiUrl = globalvar.BaseURL + DeviceFallenCriticalAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_FALLEN and level=Critical ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_FALLEN and level=Critical ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DEVICE_MARKED_REPLACED and level=Critical
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_MARKED_REPLACED_Critical == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10424)
def test_tc_000001_DEVICE_MARKED_REPLACED_Critical(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DeviceMarkedAsReplacedCriticalAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_MARKED_REPLACED', 'CRITICAL')
      apiUrl = globalvar.BaseURL + DeviceMarkedAsReplacedCriticalAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_MARKED_REPLACED and level=Critical ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_MARKED_REPLACED and level=Critical ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DEVICE_MARKED_LOST and level=Critical
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_MARKED_LOST_Critical == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10425)
def test_tc_000001_DEVICE_MARKED_LOSTCritical(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DeviceMarkedAsLostCriticalAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_MARKED_LOST', 'CRITICAL')
      apiUrl = globalvar.BaseURL + DeviceMarkedAsLostCriticalAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_MARKED_LOST and level=Critical ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_MARKED_LOST and level=Critical ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=KIOSK_LOCKED and level=Critical
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_MARKED_STOLEN_Critical == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10426)
def test_tc_000001_DEVICE_MARKED_STOLENCritical(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DeviceMarkedAsStolenCriticalAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_MARKED_STOLEN', 'CRITICAL')
      apiUrl = globalvar.BaseURL + DeviceMarkedAsStolenCriticalAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_MARKED_STOLEN and level=Critical ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_MARKED_STOLEN and level=Critical ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DEVICE_CONNECTED_BACK and level=Critical
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_CONNECTED_BACK_Critical == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10427)
def test_tc_000001_DEVICE_CONNECTED_BACKCritical(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DeviceConnectedBackCriticalAlert = url_formatter2(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_CONNECTED_BACK', 'CRITICAL')
      apiUrl = globalvar.BaseURL + DeviceConnectedBackCriticalAlert
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_CONNECTED_BACK and level=Critical ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_CONNECTED_BACK and level=Critical ---------------------------\n\n")
      assert False
# Types are different and level is ALL
# GET method to GET Alert notifications of type=Battery and level=All
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_BATTERY_ALL == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10428)
def test_tc_000001_BATTERY_ALL(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      BATTERYALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'BATTERY')
      apiUrl = globalvar.BaseURL + BATTERYALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=Battery and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=Battery and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=KIOSK_LOCKED and level=Warning
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DATA_USAGE == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10429)
def test_tc_000001_DATA_USAGE(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DATA_USAGEALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DATA_USAGE')
      apiUrl = globalvar.BaseURL + DATA_USAGEALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DATA_USAGE and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DATA_USAGE and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=KIOSK_LOCKED and level=All
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_KIOSK_LOCKED == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10430)
def test_tc_000001_KIOSK_LOCKED(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      KIOSK_LOCKEDALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'KIOSK_LOCKED')
      apiUrl = globalvar.BaseURL + KIOSK_LOCKEDALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=KIOSK_LOCKED and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=KIOSK_LOCKED and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=KIOSK_UNLOCKED and level=All
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_KIOSK_UNLOCKED == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10431)
def test_tc_000001_KIOSK_UNLOCKED(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      KIOSK_UNLOCKEDALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'KIOSK_UNLOCKED')
      apiUrl = globalvar.BaseURL + KIOSK_UNLOCKEDALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=KIOSK_UNLOCKED and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=KIOSK_UNLOCKED and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=ADMIN_LOCKED and level=All
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_ADMIN_LOCKED == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10432)
def test_tc_000001_ADMIN_LOCKED(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      ADMIN_LOCKEDALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'ADMIN_LOCKED')
      apiUrl = globalvar.BaseURL + ADMIN_LOCKEDALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=ADMIN_LOCKED and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=ADMIN_LOCKED and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DEVICE_REBOOTED and level=All
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_REBOOTED == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10433)
def test_tc_000001_DEVICE_REBOOTED(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DEVICE_REBOOTEDALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_REBOOTED')
      apiUrl = globalvar.BaseURL + DEVICE_REBOOTEDALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_REBOOTED and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_REBOOTED and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DEVICE_WIPED and level=All
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_WIPED == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10434)
def test_tc_000001_DEVICE_WIPED(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DEVICE_WIPEDALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_WIPED')
      apiUrl = globalvar.BaseURL + DEVICE_WIPEDALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_WIPED and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_WIPED and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DEVICE_DELETED and level=All
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_DELETED == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10435)
def test_tc_000001_KIOSK_DEVICE_DELETED(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DEVICE_DELETEDALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_DELETED')
      apiUrl = globalvar.BaseURL + DEVICE_DELETEDALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_DELETED and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_DELETED and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=ROOTED_ENROLL and level=All
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_ROOTED_ENROLL == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10436)
def test_tc_000001_ROOTED_ENROLL(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      ROOTED_ENROLLALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'ROOTED_ENROLL')
      apiUrl = globalvar.BaseURL + ROOTED_ENROLLALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=ROOTED_ENROLL and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=ROOTED_ENROLL and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=MEMORY_ALERT and level=All
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_MEMORY_ALERT == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10437)
def test_tc_000001_MEMORY_ALERT(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      MEMORY_ALERTALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'MEMORY_ALERT')
      apiUrl = globalvar.BaseURL + MEMORY_ALERTALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=MEMORY_ALERT and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=MEMORY_ALERT and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DISC_USAGE and level=All
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DISC_USAGE == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10438)
def test_tc_000001_DISC_USAGE(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DISC_USAGEALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DISC_USAGE')
      apiUrl = globalvar.BaseURL + DISC_USAGEALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DISC_USAGE and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DISC_USAGE and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DEVICE_FALLEN and level=All
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_FALLEN == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10439)
def test_tc_000001_DEVICE_FALLEN(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DEVICE_FALLENALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_FALLEN')
      apiUrl = globalvar.BaseURL + DEVICE_FALLENALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_FALLEN and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_FALLEN and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DEVICE_MARKED_REPLACED and level=All
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_MARKED_REPLACED == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10440)
def test_tc_000001_DEVICE_MARKED_REPLACED(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DEVICE_MARKED_REPLACEDALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_MARKED_REPLACED')
      apiUrl = globalvar.BaseURL + DEVICE_MARKED_REPLACEDALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_MARKED_REPLACED and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_MARKED_REPLACED and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DEVICE_MARKED_LOST and level=All
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_MARKED_LOST == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10441)
def test_tc_000001_DEVICE_MARKED_LOST(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DEVICE_MARKED_LOSTALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_MARKED_LOST')
      apiUrl = globalvar.BaseURL + DEVICE_MARKED_LOSTALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_MARKED_LOST and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_MARKED_LOST and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DEVICE_MARKED_STOLEN and level=All
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_MARKED_STOLEN == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10442)
def test_tc_000001_DEVICE_MARKED_STOLEN(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DEVICE_MARKED_STOLENALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_MARKED_STOLEN')
      apiUrl = globalvar.BaseURL + DEVICE_MARKED_STOLENALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_MARKED_STOLEN and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_MARKED_STOLEN and level=All ---------------------------\n\n")
      assert False
# GET method to GET Alert notifications of type=DEVICE_CONNECTED_BACK and level=All
@pytest.mark.parametrize('url', [""])
@pytest.mark.skipif(Executor.test_tc_001_AlertsModule_DEVICE_CONNECTED_BACK == 0, reason="This test must run, it is mandatory. Without this test rest of test case execution should stop")
@pytest.mark.positivetest
@pytest.mark.usualtest
@pytest.mark.sanitytest
@pytest.mark.sprint20
@pytest.mark.alerts
@pytest.mark.regressiontest
@pytest.mark.run(order=10443)
def test_tc_000001_DEVICE_CONNECTED_BACK(url):
  now1 =datetime.now()
  if globalvar.bearerToken == '':
      pytest.skip("Empty Bearer token. Skipping test")
  try:
      DEVICE_CONNECTED_BACKALL = url_formatter3(globalvar.accountId, variable.isostart, variable.isoend, globals.page_1, globals.pagesize_10, 'DEVICE_CONNECTED_BACK')
      apiUrl = globalvar.BaseURL + DEVICE_CONNECTED_BACKALL
      Headers = {'Authorization': 'Bearer {}'.format(globalvar.bearerToken)}
      res = requests.get(url=apiUrl, headers=Headers, timeout=globalvar.timeout)
      curl_str1 = utils.getCurlEquivalent(res)
      print(curl_str1)
      print(res.content)
      WeGuard.logger.debug("\n Response Headers: " + str(res.headers) + "\n Response code: " + str(res.status_code) + "\n apiUrl: " + apiUrl + "\n Response: " + str(res.content))
      print("\n\n--------------------------- Alert notifications of type=DEVICE_CONNECTED_BACK and level=All ---------------------------")
      assert res.status_code == 200
  except BaseException as e:
      print('Error at %s', 'BaseException')
      now2 = datetime.now()
      WeGuard.logger.warning("Time taken: " + str(now2 - now1))
      print("\n\n--------------------------- Not available alert notifications of type=DEVICE_CONNECTED_BACK and level=All ---------------------------\n\n")
      assert False
